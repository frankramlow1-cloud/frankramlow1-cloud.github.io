// Video-Schnitt – speichert die App auf dem Handy, damit sie auch ohne laufenden Server startet
const CACHE = 'video-schnitt-v3';
const FILES = ['index.html', 'manifest.json', 'icon-192.png', 'icon-512.png'];
const base = self.registration.scope;
self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    for (const f of FILES) {
      try { const r = await fetch(new Request(base + f, { cache: 'reload' })); if (r.ok) await c.put(base + f, r); } catch (err) { }
    }
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('message', async e => {
  if (e.data === 'check') {
    const c = await caches.open(CACHE); const hit = await c.match(base + 'index.html');
    e.source && e.source.postMessage({ cached: !!hit });
  }
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || !req.url.startsWith(base)) return;
  const isPage = req.mode === 'navigate' || /\/(index\.html)?(\?.*)?$/.test(new URL(req.url).pathname + new URL(req.url).search);
  const key = isPage ? base + 'index.html' : req.url.split('?')[0];
  e.respondWith((async () => {
    const c = await caches.open(CACHE);
    const hit = await c.match(key);
    const net = fetch(req).then(r => { if (r && r.ok && r.type === 'basic') c.put(key, r.clone()); return r; }).catch(() => null);
    if (hit) { e.waitUntil(net); return hit; }
    const r = await net;
    return r || new Response('<h2 style="font-family:serif;color:#ecc56a;background:#1a0a03;padding:30px">Bitte einmal mit laufendem Server öffnen.</h2>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
  })());
});
