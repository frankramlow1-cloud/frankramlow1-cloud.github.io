// Radio Retro – Offline-Speicher für die App selbst (nicht für die Musik)
// Damit startet die App auch dann, wenn der Datei-Manager geschlossen ist.
const CACHE = 'radio-retro-v3';
const FILES = ['index.html', 'manifest.json', 'bg.jpg', 'cap.png', 'knob.png', 'icon-192.png', 'icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    // jede Datei einzeln – ein einzelner Fehler bricht nicht alles ab
    await Promise.allSettled(FILES.map(async f => {
      const res = await fetch(f, { cache: 'reload' });
      if (res.ok) await c.put(new URL(f, self.registration.scope).href, res);
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  e.respondWith((async () => {
    const c = await caches.open(CACHE);
    // App-Seite selbst: immer die gespeicherte index.html (auch ohne Datei-Manager)
    if (e.request.mode === 'navigate') {
      const page = await c.match(new URL('index.html', self.registration.scope).href);
      if (page) return page;
    }
    const hit = await c.match(e.request, { ignoreSearch: true });
    if (hit) return hit;
    try {
      const res = await fetch(e.request);
      if (res.ok) c.put(e.request, res.clone());
      return res;
    } catch (err) {
      return new Response('', { status: 504 });
    }
  })());
});
